// COMP5911M Coursework 1, Task 1

package ase.cwk1;

import java.io.IOException;
import java.io.Writer;
import java.util.List;

import java.io.PrintWriter;
import java.util.ArrayList;


public class Report {
  private Writer output;

  public Report(Writer output) {
    this.output = output;
  }

  public void print(List<Machine> machines, Robot robot) throws IOException {
    output.write("FACTORY REPORT\n\n");

    for (Machine machine: machines) {
      output.write("Machine " + machine.getName());
      if (machine.getItem() != null) {
        output.write(" item=" + machine.getItem());
      }
      output.write("\n");
    }
    output.write("\n");

    output.write("Robot");
    if (robot.getLocation() != null) {
      output.write(" location=" + robot.getLocation().getName());
    }
    if (robot.getItem() != null) {
      output.write(" item=" + robot.getItem());
    }
    output.write("\n");

    output.write("\nEND\n");
  }
}
